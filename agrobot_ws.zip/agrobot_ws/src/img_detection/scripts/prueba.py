#!/usr/bin/python3
import cv2 as cv
from modelPredict import modelPredict

def main():
    try:
        modelo = modelPredict("/home/al3x/S8/agrobot_ws/src/img_detection/scripts/plantas.onnx",
                              ['Beans_Angular_LeafSpot', 'Beans_Rust', 'Strawberry_Angular_LeafSpot', 'Strawberry_Anthracnose_Fruit_Rot', 'Strawberry_Blossom_Blight', 'Strawberry_Gray_Mold', 'Straberry_Leaf_Spot', 'Straberry_Powdery_Mildew_Fruit', 'Straberry_Powdery_Mildew_Leaf', 'Tomato_Blight', 'Tomato_Leaf_Mold','Tomato_Spider_Mites'],0.6,True)
        
        # Load the image from the "Pictures" folder
        img_path = "/home/al3x/Pictures/planta1.jpeg"  # Replace "your_image.jpg" with the actual image file name
        frame = cv.imread(img_path)
        
        if frame is None:
            print("Error: Could not load the image.")
            return
        
        # Perform detection
        modelo._startDetection(frame, "Beans_Angular_LeafSpot", 0.5)
        
    except KeyboardInterrupt as ki:
        print(ki)

if __name__ == '__main__':
    main()
